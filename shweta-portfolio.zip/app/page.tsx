import Image from "next/image"
import Link from "next/link"
import { Github, Linkedin, Mail, Shield, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import ProjectCard from "@/components/project-card"
import SkillBar from "@/components/skill-bar"
import CertificationCard from "@/components/certification-card"
import BlogPostCard from "@/components/blog-post-card"
import ContactForm from "@/components/contact-form"

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-950 text-gray-100">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-b from-gray-900 to-gray-950">
        <div className="absolute inset-0 bg-[url('/cyber-bg.svg')] bg-cover opacity-10"></div>
        <div className="container px-4 mx-auto z-10 flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 text-center md:text-left mb-10 md:mb-0">
            <h1 className="text-4xl md:text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-500">
              Shweta
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold mb-6">Cybersecurity Professional</h2>
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              Dedicated to securing digital landscapes and protecting data integrity through innovative solutions and
              best practices.
            </p>
            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              <Button className="bg-cyan-600 hover:bg-cyan-700">
                <Link href="#contact" className="flex items-center gap-2">
                  <Mail size={18} /> Contact Me
                </Link>
              </Button>
              <Button variant="outline" className="border-cyan-600 text-cyan-400 hover:bg-cyan-950">
                <Link href="#projects" className="flex items-center gap-2">
                  <Shield size={18} /> View Projects
                </Link>
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-cyan-600">
              <Image
                src="/placeholder.svg?height=320&width=320"
                alt="Shweta's profile"
                fill
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
          <Link href="#about" aria-label="Scroll down">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-cyan-400"
            >
              <path d="M12 5v14M5 12l7 7 7-7" />
            </svg>
          </Link>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-900">
        <div className="container px-4 mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            <span className="border-b-4 border-cyan-500 pb-2">About Me</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-cyan-400">My Journey</h3>
              <p className="text-gray-300 mb-6">
                I am a passionate cybersecurity professional with expertise in vulnerability assessment, penetration
                testing, and security architecture. My journey in cybersecurity began during my undergraduate studies,
                where I discovered my passion for protecting digital assets and information systems.
              </p>
              <p className="text-gray-300">
                With a strong foundation in both offensive and defensive security practices, I strive to help
                organizations build robust security postures that can withstand modern threats while enabling business
                objectives.
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-cyan-400">Education & Background</h3>
              <div className="mb-4">
                <h4 className="text-xl font-medium">Bachelor of Technology in Computer Science</h4>
                <p className="text-gray-400">University Name • 2019-2023</p>
              </div>
              <div>
                <h4 className="text-xl font-medium">Specialized Training</h4>
                <ul className="list-disc list-inside text-gray-300 mt-2">
                  <li>Certified Ethical Hacker (CEH)</li>
                  <li>CompTIA Security+</li>
                  <li>Offensive Security Certified Professional (OSCP)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-950">
        <div className="container px-4 mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            <span className="border-b-4 border-cyan-500 pb-2">Projects</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ProjectCard
              title="Network Intrusion Detection System"
              description="Developed a custom NIDS using machine learning algorithms to detect anomalous network traffic patterns with 95% accuracy."
              tags={["Python", "TensorFlow", "Network Security"]}
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <ProjectCard
              title="Secure File Sharing Application"
              description="Built an end-to-end encrypted file sharing platform with zero-knowledge architecture and multi-factor authentication."
              tags={["React", "Node.js", "Cryptography"]}
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <ProjectCard
              title="Vulnerability Management Dashboard"
              description="Created a comprehensive dashboard for tracking and prioritizing security vulnerabilities across enterprise systems."
              tags={["Vue.js", "GraphQL", "Risk Assessment"]}
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <ProjectCard
              title="Phishing Awareness Training Platform"
              description="Designed an interactive training platform to educate employees about phishing threats and social engineering tactics."
              tags={["JavaScript", "Gamification", "Security Awareness"]}
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <ProjectCard
              title="IoT Security Framework"
              description="Developed a security framework for IoT devices with secure boot, encrypted communication, and automated patching."
              tags={["C++", "Embedded Systems", "IoT Security"]}
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <ProjectCard
              title="Security Compliance Automation Tool"
              description="Built a tool to automate security compliance checks against standards like NIST, ISO 27001, and GDPR."
              tags={["Python", "Docker", "Compliance"]}
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gray-900">
        <div className="container px-4 mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            <span className="border-b-4 border-cyan-500 pb-2">Skills</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-cyan-400">Technical Skills</h3>
              <div className="space-y-6">
                <SkillBar skill="Penetration Testing" percentage={90} />
                <SkillBar skill="Network Security" percentage={85} />
                <SkillBar skill="Malware Analysis" percentage={75} />
                <SkillBar skill="Cloud Security (AWS/Azure)" percentage={80} />
                <SkillBar skill="Security Architecture" percentage={85} />
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-cyan-400">Tools & Technologies</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Security Tools</h4>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Metasploit Framework</li>
                    <li>• Wireshark</li>
                    <li>• Burp Suite</li>
                    <li>• Nessus</li>
                    <li>• OWASP ZAP</li>
                  </ul>
                </div>
                <div className="bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Programming</h4>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Python</li>
                    <li>• Bash Scripting</li>
                    <li>• JavaScript</li>
                    <li>• C/C++</li>
                    <li>• SQL</li>
                  </ul>
                </div>
                <div className="bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Platforms</h4>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Linux</li>
                    <li>• Windows Server</li>
                    <li>• AWS</li>
                    <li>• Azure</li>
                    <li>• Docker/Kubernetes</li>
                  </ul>
                </div>
                <div className="bg-gray-800 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Methodologies</h4>
                  <ul className="text-gray-300 space-y-1">
                    <li>• OWASP Top 10</li>
                    <li>• MITRE ATT&CK</li>
                    <li>• ISO 27001</li>
                    <li>• NIST Cybersecurity</li>
                    <li>• DevSecOps</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="py-20 bg-gray-950">
        <div className="container px-4 mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            <span className="border-b-4 border-cyan-500 pb-2">Certifications</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <CertificationCard
              title="Certified Ethical Hacker (CEH)"
              issuer="EC-Council"
              date="January 2022"
              image="/placeholder.svg?height=100&width=100"
              link="#"
            />
            <CertificationCard
              title="CompTIA Security+"
              issuer="CompTIA"
              date="March 2021"
              image="/placeholder.svg?height=100&width=100"
              link="#"
            />
            <CertificationCard
              title="Offensive Security Certified Professional (OSCP)"
              issuer="Offensive Security"
              date="August 2022"
              image="/placeholder.svg?height=100&width=100"
              link="#"
            />
            <CertificationCard
              title="Certified Information Systems Security Professional (CISSP)"
              issuer="(ISC)²"
              date="December 2022"
              image="/placeholder.svg?height=100&width=100"
              link="#"
            />
            <CertificationCard
              title="AWS Certified Security - Specialty"
              issuer="Amazon Web Services"
              date="May 2023"
              image="/placeholder.svg?height=100&width=100"
              link="#"
            />
            <CertificationCard
              title="Certified Cloud Security Professional (CCSP)"
              issuer="(ISC)²"
              date="February 2023"
              image="/placeholder.svg?height=100&width=100"
              link="#"
            />
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section id="blog" className="py-20 bg-gray-900">
        <div className="container px-4 mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            <span className="border-b-4 border-cyan-500 pb-2">Blog</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BlogPostCard
              title="Understanding Zero-Day Vulnerabilities"
              excerpt="An in-depth look at zero-day vulnerabilities, how they're discovered, and strategies for mitigation."
              date="April 15, 2023"
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <BlogPostCard
              title="Implementing Zero Trust Architecture"
              excerpt="A practical guide to implementing zero trust security models in modern enterprise environments."
              date="March 22, 2023"
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
            <BlogPostCard
              title="The Rise of Ransomware-as-a-Service"
              excerpt="Exploring the growing threat of RaaS platforms and how organizations can prepare their defenses."
              date="February 10, 2023"
              image="/placeholder.svg?height=200&width=300"
              link="#"
            />
          </div>
          <div className="text-center mt-10">
            <Button className="bg-cyan-600 hover:bg-cyan-700">
              <Link href="/blog" className="flex items-center gap-2">
                <FileText size={18} /> View All Posts
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-950">
        <div className="container px-4 mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">
            <span className="border-b-4 border-cyan-500 pb-2">Contact Me</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div>
              <h3 className="text-2xl font-semibold mb-6 text-cyan-400">Get In Touch</h3>
              <p className="text-gray-300 mb-8">
                I'm always open to discussing new projects, cybersecurity challenges, or opportunities to collaborate.
                Feel free to reach out using the contact form or through my social media profiles.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="text-cyan-400" />
                  <span>shweta@example.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <Linkedin className="text-cyan-400" />
                  <a
                    href="https://linkedin.com/in/shweta"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-cyan-400 transition-colors"
                  >
                    linkedin.com/in/shweta
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <Github className="text-cyan-400" />
                  <a
                    href="https://github.com/shweta"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-cyan-400 transition-colors"
                  >
                    github.com/shweta
                  </a>
                </div>
              </div>
            </div>
            <div>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gray-900 border-t border-gray-800">
        <div className="container px-4 mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <p className="text-gray-400">© {new Date().getFullYear()} Shweta. All rights reserved.</p>
            </div>
            <div className="flex space-x-4">
              <a
                href="https://github.com/shweta"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="GitHub"
                className="text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Github size={20} />
              </a>
              <a
                href="https://linkedin.com/in/shweta"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className="text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Linkedin size={20} />
              </a>
              <a
                href="mailto:shweta@example.com"
                aria-label="Email"
                className="text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}

