import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import BlogPostCard from "@/components/blog-post-card"

export default function BlogPage() {
  // Sample blog posts data - in a real app, this would come from a database or CMS
  const blogPosts = [
    {
      title: "Understanding Zero-Day Vulnerabilities",
      excerpt: "An in-depth look at zero-day vulnerabilities, how they're discovered, and strategies for mitigation.",
      date: "April 15, 2023",
      image: "/placeholder.svg?height=200&width=300",
      link: "#",
    },
    {
      title: "Implementing Zero Trust Architecture",
      excerpt: "A practical guide to implementing zero trust security models in modern enterprise environments.",
      date: "March 22, 2023",
      image: "/placeholder.svg?height=200&width=300",
      link: "#",
    },
    {
      title: "The Rise of Ransomware-as-a-Service",
      excerpt: "Exploring the growing threat of RaaS platforms and how organizations can prepare their defenses.",
      date: "February 10, 2023",
      image: "/placeholder.svg?height=200&width=300",
      link: "#",
    },
    {
      title: "Secure Coding Practices for Developers",
      excerpt: "Essential security practices every developer should follow to build more secure applications.",
      date: "January 28, 2023",
      image: "/placeholder.svg?height=200&width=300",
      link: "#",
    },
    {
      title: "Cloud Security Best Practices",
      excerpt: "Key strategies for securing cloud infrastructure and applications in AWS, Azure, and GCP.",
      date: "December 15, 2022",
      image: "/placeholder.svg?height=200&width=300",
      link: "#",
    },
    {
      title: "The Importance of Security Awareness Training",
      excerpt: "Why human factors remain the biggest security vulnerability and how to address them effectively.",
      date: "November 30, 2022",
      image: "/placeholder.svg?height=200&width=300",
      link: "#",
    },
  ]

  return (
    <main className="min-h-screen bg-gray-950 text-gray-100">
      <div className="container px-4 mx-auto py-16">
        <div className="mb-12">
          <Button variant="outline" className="mb-6">
            <Link href="/" className="flex items-center gap-2">
              <ArrowLeft size={16} /> Back to Home
            </Link>
          </Button>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Cybersecurity Blog</h1>
          <p className="text-xl text-gray-300">
            Insights, tutorials, and analysis on the latest cybersecurity trends and challenges.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <BlogPostCard
              key={index}
              title={post.title}
              excerpt={post.excerpt}
              date={post.date}
              image={post.image}
              link={post.link}
            />
          ))}
        </div>
      </div>
    </main>
  )
}

