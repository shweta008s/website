import Image from "next/image"
import Link from "next/link"
import { Calendar, ArrowRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface BlogPostCardProps {
  title: string
  excerpt: string
  date: string
  image: string
  link: string
}

export default function BlogPostCard({ title, excerpt, date, image, link }: BlogPostCardProps) {
  return (
    <Card className="bg-gray-800 border-gray-700 overflow-hidden hover:border-cyan-500 transition-all duration-300 h-full flex flex-col">
      <div className="relative h-48 w-full">
        <Image src={image || "/placeholder.svg"} alt={title} fill className="object-cover" />
      </div>
      <CardContent className="p-6 flex-grow">
        <div className="flex items-center gap-1 text-gray-400 text-sm mb-2">
          <Calendar size={14} />
          <span>{date}</span>
        </div>
        <h3 className="text-xl font-semibold mb-2 text-cyan-400">{title}</h3>
        <p className="text-gray-300 mb-4">{excerpt}</p>
        <Link
          href={link}
          className="text-cyan-400 hover:text-cyan-300 flex items-center gap-2 text-sm font-medium mt-auto"
        >
          Read More <ArrowRight size={14} />
        </Link>
      </CardContent>
    </Card>
  )
}

