import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Award, Calendar, ExternalLink } from "lucide-react"

interface CertificationCardProps {
  title: string
  issuer: string
  date: string
  image: string
  link: string
}

export default function CertificationCard({ title, issuer, date, image, link }: CertificationCardProps) {
  return (
    <Card className="bg-gray-800 border-gray-700 hover:border-cyan-500 transition-all duration-300">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="relative h-16 w-16 flex-shrink-0">
            <Image src={image || "/placeholder.svg"} alt={issuer} fill className="object-contain" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-cyan-400">{title}</h3>
            <div className="flex items-center gap-1 text-gray-300 text-sm mt-1">
              <Award size={14} className="text-gray-400" />
              <span>{issuer}</span>
            </div>
            <div className="flex items-center gap-1 text-gray-400 text-sm mt-1">
              <Calendar size={14} />
              <span>{date}</span>
            </div>
            <a
              href={link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 text-sm mt-2"
            >
              View Certificate <ExternalLink size={14} />
            </a>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

